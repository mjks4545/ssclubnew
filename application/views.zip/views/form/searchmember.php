<div class="content-wrapper">
        <!-- Content Header (Page header) -->
        <section class="content-header">
          <h1>
            Membership Search
            <small></small>
          </h1>
        </section>

        <!-- Main content -->
        <section class="content">
         <!-- SELECT2 EXAMPLE -->
          <div class="box box-default">
            <div class="box-header with-border">
              <h3 class="box-title">Membership Search</h3>
            </div><!-- /.box-header -->
            <div class="box-body">
			  <div class="box-header">
              <a href="#" type="button" name="button" class="btn btn-default" value="">Show All Members</a>
              </div>
              <div class="row">
                <div class="col-md-6 col-sm-6 col-xs-6 col-xs-offset-3">
                  <div class="form-group">
                    <label>Name</label>
                    <input type="text" name="name" class="form-control" style="width: 100%;">
                  </div><!-- /.form-group -->
                </div><!-- /.col -->
				<div class="col-md-6 col-sm-6 col-xs-6 col-xs-offset-3">
                  <div class="form-group">
                    <label>Cnic No</label>
                    <input type="text" name="cnic_no" class="form-control" style="width: 100%;">
                  </div><!-- /.form-group -->
                </div>
				<div class="col-md-6 col-sm-6 col-xs-6 col-xs-offset-3">
                  <div class="form-group">
                    <label>Card No</label>
                    <input type="text" name="card_no" class="form-control" style="width: 100%;">
                  </div><!-- /.form-group -->
                 </div>
				<div class="col-md-6 col-sm-6 col-xs-6 col-xs-offset-3">
                  <div class="form-group">
                    <label>Membership</label>
                    <select name="card_no" class="form-control" style="width: 100%;">
						<option>Select Membership</option>
						<option>Gold</option>
						<option>silver</option>
					</select>
                  </div><!-- /.form-group -->
                </div>
				<div class="col-md-6 col-sm-6 col-xs-6 col-xs-offset-3">
                  <div class="form-group">
                    <label>Mobile</label>
                    <input type="text" name="mobile" class="form-control" style="width: 100%;">
                  </div><!-- /.form-group -->
                </div>
				<div class="col-md-6 col-sm-6 col-xs-6 col-xs-offset-3">
                  <div class="form-group">
                    <label>License No</label>
                    <input type="text" name="license_no" class="form-control" style="width: 100%;">
                   </div><!-- /.form-group -->
                </div>
				<div class="col-md-6 col-sm-6 col-xs-6 col-xs-offset-3">
                  <div class="form-group">
                    <label>Search All Member</label>
                    <a href="#" type="button" name="license_no" class="btn btn-info" style="width: 100%;">Search All Members</a>
                  </div><!-- /.form-group -->
                </div>
				<div class="col-md-2 col-sm-2 col-xs-2 col-xs-offset-5">
                  <div class="form-group">
                    <label>Search</label>
                    <input type="submit" name="submit" class="btn btn-warning" style="width: 100%;">
                      
                  </div><!-- /.form-group -->
                </div>
				
              </div><!-- /.row -->
            </div><!-- /.box-body -->
           
          </div><!-- /.box -->
       </section><!-- /.content -->
      </div><!-- /.content-wrapper -->